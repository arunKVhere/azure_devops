# Sample Aus-E-Mart Web App from cloudlee

This is a basic web app built using the dotnet webapp template, to help demonstrate content in various Azure courses at [learn.cloudlee.io](https://learn.cloudlee.io). 

## Usage

Refer to the course lessons for more information on how to use this sample web app.

